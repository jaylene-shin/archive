import os
from typing import List

import onnxruntime as ort
import torch
import numpy as np
from lib.pyminio import PyMinio

from ray import serve
import starlette.requests
from transformers import RobertaTokenizer


async def json_resolver(request: starlette.requests.Request) -> List:
    return await request.json()


def preprocess(input_text, tokenizer):
    input_ids = torch.tensor(tokenizer.encode(input_text)).unsqueeze(0)  # Batch size 1
    return input_ids


@serve.deployment
class RobertaOnnxInferencer:
    def __init__(self):
        self.input_ids = None
        self.model = None
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")

    @serve.multiplexed(max_num_models_per_replica=1)
    async def load_model(self, model_id: str):  # model_id는 multiplexing 용도로 활용
        model_path = os.getenv("MODEL_PATH", "/curas/ray-test/model")
        model_name = os.getenv("MODEL_NAME", "roberta-sequence-classification")
        model = PyMinio.get(f"{model_path}/{model_name}-{model_id}.onnx")
        return model

    def inference(self) -> List[float]:
        def to_numpy(tensor):
            return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

        ort_session = ort.InferenceSession(self.model)
        ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(self.input_ids)}
        ort_out = ort_session.run(None, ort_inputs)
        return ort_out

    def postprocess(self, ort_out):
        pred = np.argmax(ort_out)
        if pred == 0:
            return "Prediction: negative"
        elif pred == 1:
            return "Prediction: positive"

    async def __call__(self, request: starlette.requests.Request):
        model_id = serve.get_multiplexed_model_id()
        json_req = await json_resolver(request)
        preprocess(json_req["sentence"], self.tokenizer)
        model = await self.load_model(model_id)
        self.model = model
        ort_out = self.inference()
        return self.postprocess(ort_out)


roberta_infer = RobertaOnnxInferencer.bind()
