import io

from minio import Minio
from pyvault import PyVault


class PyMinio:
    secret_data = PyVault().get_secret_data()
    minio_client = Minio(
        endpoint=secret_data["tenth2_host"],
        access_key=secret_data["tenth2_access_key"],
        secret_key=secret_data["tenth2_secret_key"],
        secure=False
    )

    @classmethod
    def get(cls, meta_path: str):
        bucket_name, object_name = PyMinio.bucket_and_object_from_tenth_path(meta_path)
        try:
            response = cls.minio_client.get_object(
                bucket_name=bucket_name,
                object_name=object_name
            )
            return response.data
        except Exception as e:
            print("Error while getting object:", e)

    @classmethod
    def put(cls, meta_path: str, body: bytes):
        bucket_name, object_name = PyMinio.bucket_and_object_from_tenth_path(meta_path)
        try:
            cls.minio_client.put_object(
                bucket_name=bucket_name,
                object_name=object_name,
                length=len(body),
                data=io.BytesIO(body)
            )
        except Exception as e:
            print("Error while putting object:", e)

    @classmethod
    def make_bucket(cls, bucket_name: str):
        try:
            cls.minio_client.make_bucket(bucket_name)
        except Exception as e:
            print("Error while creating bucket:", e)

    @classmethod
    def remove_bucket(cls, bucket_name: str, dir_path: str):
        try:
            objects = cls.minio_client.list_objects(bucket_name, prefix=dir_path, recursive=True)
            for obj in objects:
                cls.minio_client.remove_object(bucket_name, obj.object_name)
        except Exception as e:
            print("Error while removing objects:", e)

        try:
            cls.minio_client.remove_bucket(bucket_name)
        except Exception as e:
            print("Error while removing bucket:", e)

    @staticmethod
    def bucket_and_object_from_tenth_path(meta_path: str):
        """
        테스트 인풋 형식이 변경되면 삭제될 메서드
        """
        path_elems = meta_path.split("/")
        bucket_name = path_elems[2]
        object_name = "/".join(path_elems[3:])
        return bucket_name, object_name
