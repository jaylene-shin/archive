import os
from typing import List

import onnxruntime as ort
import torch
import numpy as np
from lib.pyminio import PyMinio

from ray import serve
import starlette.requests
from transformers import RobertaTokenizer


@serve.deployment
class RobertaOnnxInferencer:
    def __init__(self):
        self.input_ids = None
        self.model = None
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")

    @serve.multiplexed(max_num_models_per_replica=3)
    async def load_model(self, model_id: str):  # model_id는 multiplexing 용도로 활용
        model_path = os.getenv("MODEL_PATH", "/curas/ray-test/model")
        model_name = os.getenv("MODEL_NAME", "roberta-sequence-classification")
        model = PyMinio.get(f"{model_path}/{model_name}-{model_id}.onnx")
        return model

    @serve.deployment(num_replicas=1)
    def preprocess(self, input_text):
        input_ids = torch.tensor(self.tokenizer.encode(input_text)).unsqueeze(0)  # Batch size 1
        self.input_ids = input_ids
        return input_ids

    @serve.deployment(num_replicas=1)  # NOTE: model_multiplexing을 활용할 경우에 계속 모델을 생성해야 하는 구조?
    def inference(self) -> List[float]:
        def to_numpy(tensor):
            return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

        ort_session = ort.InferenceSession(self.model)
        ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(self.input_ids)}
        ort_out = ort_session.run(None, ort_inputs)
        return ort_out

    @serve.deployment(num_replicas=1)
    def postprocess(self, ort_out):
        pred = np.argmax(ort_out)
        if pred == 0:
            return "Prediction: negative"
        elif pred == 1:
            return "Prediction: positive"

    async def __call__(self, request: starlette.requests.Request):
        async def json_resolver(request: starlette.requests.Request) -> List:
            return await request.json()

        model_id = serve.get_multiplexed_model_id()
        print("====DEBUG====")
        print(model_id)
        model = await self.load_model(model_id)
        self.model = model
        json_req = await json_resolver(request)
        print(json_req)
        self.preprocess(json_req["sentence"])
        ort_out = self.inference()
        return self.postprocess(ort_out)


roberta_infer = RobertaOnnxInferencer.bind()
