from typing import List

import numpy as np
import onnxruntime as ort


class OnnxModel:
    MIN_SCORE = 0.0
    MAX_SCORE = 1.0

    def __init__(self, test_model):
        self.session = ort.InferenceSession(test_model)
        self.input_name = self.session.get_inputs()[0].name
        self.output_scores = None

    def run_inference(self, input_data) -> List[float]:
        input_data = np.array(input_data)
        self.output_scores = self.session.run(None, {self.input_name: input_data})[0]
        self.bound_scores()
        return self.output_scores

    def bound_scores(self) -> None:
        self.output_scores = list(map(lambda score: 0.0 if (score[0] < OnnxModel.MIN_SCORE or score[0] > OnnxModel.MAX_SCORE) else score[0], self.output_scores))

