import os
from typing import List

import numpy as np
import onnxruntime as ort
import torch
import numpy as np
from lib.pyminio import PyMinio

import ray
from pyminio import PyMinio
from ray import serve
import starlette.requests
from ray.serve.drivers import DAGDriver
from ray.serve.deployment_graph import InputNode
from ray.serve.handle import RayServeHandle

from simpletransformers.model import TransformerModel
from transformers import RobertaForSequenceClassification, RobertaTokenizer


# model multiplexing sample
@serve.deployment
class RobertaOnnxInferencer:
    def __init__(self):
        self.input_ids = None
        self.tokenizer = RobertaTokenizer.from_pretrained("roberta-base")

    @serve.multiplexed(max_num_models_per_replica=3)  # (원문 )configure how many models to load in a single replica.
    def get_model(self, model_id: str):  # model_id는 model multiplexing에서 활용한다.
        # TODO validate onnx model format
        model_path = os.getenv("MODEL_PATH", "/curas/ray-test/model")
        model_name = os.getenv("MODEL_NAME", "roberta-sequence-classification")
        model = PyMinio.get(f"{model_path}/{model_name}-{model_id}.onnx")
        return model

    @serve.deployment(num_replicas=1)
    def preprocess(self, input_text):
        input_ids = torch.tensor(self.tokenizer.encode(input_text)).unsqueeze(0)  # Batch size 1
        self.input_ids = input_ids
        return input_ids

    @serve.deployment(num_replicas=1)
    def inference(self, model_id: str) -> List[float]:
        def to_numpy(tensor):
            return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

        model = self.get_model(model_id)  # 테스트 임시
        ort_session = ort.InferenceSession(model)
        ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(self.input_ids)}
        ort_out = ort_session.run(None, ort_inputs)
        return ort_out

    @serve.deployment(num_replicas=1)
    def postprocess(self, ort_out):
        pred = np.argmax(ort_out)
        if pred == 0:
            return "Prediction: negative"
        elif pred == 1:
            return "Prediction: positive"

    def __call__(self, request: starlette.requests.Request):
        model_id = serve.get_multiplexed_model_id()  ## 테스트
        self.preprocess("This film is so good")  # request로 넣어야 함
        ort_out = self.inference(model_id)
        return self.postprocess(ort_out)


onnx_infer_app = RobertaOnnxInferencer.bind()
