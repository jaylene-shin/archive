import json
import os
import requests


class PyVault:
    def __init__(self):
        self.url = os.getenv('VAULT_URL', default="")
        self.role_id = os.getenv('ROLE_ID', default="")
        self.secret_id = os.getenv('SECRET_ID', default="")
        self.token = self.__get_token(self.role_id, self.secret_id)

    def get_secret_data(self, secret_path="secret/curas-sandbox/curas/db-keys"):
        url = f'{self.url}/v1/{secret_path}'
        headers = {'X-Vault-Token': self.token}
        response = requests.get(url=url, headers=headers)
        self._check_response(response)
        return json.loads(response.text)['data']

    def _check_response(self, response):
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError:
            print(f'Vault Request Error - Response : {response.text}')
            raise

    def __get_token(self, role_id, secret_id):
        url = f'{self.url}/v1/auth/approle/login'
        data = {
            'role_id': role_id,
            'secret_id': secret_id
        }
        response = requests.post(url=url, json=data)
        self._check_response(response)
        return json.loads(response.text)['auth']['client_token']
