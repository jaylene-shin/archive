from typing import List

import numpy as np
import onnxruntime as ort
import torch
import numpy as np
from simpletransformers.model import TransformerModel
from transformers import RobertaForSequenceClassification, RobertaTokenizer


class SentimentModel:  # TODO  input : "This film is so good" 과 같은 감정 섞인 문장으로 테스트, onnx file remote path로 수정하기
    def __init__(self):
        self.input_ids = None

    def preprocess(self, input_text):
        tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
        input_ids = torch.tensor(tokenizer.encode(input_text)).unsqueeze(0)  # Batch size 1
        self.input_ids = input_ids
        return input_ids

    def inference(self) -> List[float]:
        def to_numpy(tensor):
            return tensor.detach().cpu().numpy() if tensor.requires_grad else tensor.cpu().numpy()

        ort_session = ort.InferenceSession("../../resource/roberta-sequence-classification-9.onnx")
        ort_inputs = {ort_session.get_inputs()[0].name: to_numpy(self.input_ids)}
        ort_out = ort_session.run(None, ort_inputs)
        return ort_out

    def postprocess(self, ort_out):
        pred = np.argmax(ort_out)
        if pred == 0:
            return "Prediction: negative"
        elif pred == 1:
            return "Prediction: positive"
